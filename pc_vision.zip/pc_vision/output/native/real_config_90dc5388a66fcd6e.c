/* GENERATED from pc_vision/game_config.json; do not edit. */
#include "game_pump.h"
#include "game_render.h"
const GameConfig game_default_config = {
    .version = GAME_CONFIG_VERSION,
    .coordinate_space = "uncalibrated_preview",
    .width = 1279.0f, .height = 719.0f,
    .physics_scale = 100.0f,
    .max_models = 6,
    .render_max_ray_segments = 5,
    .scene_max_age_ms = 250ULL,
    .duration_ms = 180000ULL,
    .star_threshold_ms = {60000ULL, 120000ULL},
    .model_sizes = {
        [RAY_OBJECT_MIRROR] = {162.0f, 10.0f},
        [RAY_OBJECT_PORTAL_A] = {154.0f, 58.0f},
        [RAY_OBJECT_PORTAL_B] = {160.0f, 58.0f},
        [RAY_OBJECT_TARGET] = {80.0f, 80.0f},
        [RAY_OBJECT_SOURCE] = {54.0f, 40.0f},
        [RAY_OBJECT_WALL] = {160.0f, 32.0f},
    },
    .level_count = 3,
    .levels = {
        {.id = 1U, .reference = "sample_photo(1)/125.png",
         .emitter = {.enabled = 1, .point = {354.1875f, 465.3125f}, .direction = {0.8347785465f, -0.5505858501f}},
         .object_count = 2, .objects = {
            {.anchor = {.type = RAY_OBJECT_MIRROR,
                .center = {619.5625f, 293.5625f}, .axis = {0.01750082002f, 0.9998468489f},
                .direction_valid = 0},
             .motion = GAME_FREE},
            {.anchor = {.type = RAY_OBJECT_TARGET,
                .center = {345.0f, 104.0f}, .axis = {1.0f, 0.0f},
                .direction_valid = 0},
             .motion = GAME_FREE},
         }},
        {.id = 2U, .reference = "sample_photo(1)/130.png",
         .emitter = {.enabled = 1, .point = {998.3125f, 323.0f}, .direction = {-0.9956469956f, 0.09320439935f}},
         .object_count = 3, .objects = {
            {.anchor = {.type = RAY_OBJECT_TARGET,
                .center = {281.0f, 125.0f}, .axis = {1.0f, 0.0f},
                .direction_valid = 0},
             .motion = GAME_FREE},
            {.anchor = {.type = RAY_OBJECT_PORTAL_A,
                .center = {859.5f, 323.625f}, .axis = {0.03489967945f, -0.9993908206f},
                .direction_valid = 0},
             .motion = GAME_FREE},
            {.anchor = {.type = RAY_OBJECT_PORTAL_B,
                .center = {427.125f, 121.75f}, .axis = {0.03489967945f, -0.9993908206f},
                .direction_valid = 0},
             .motion = GAME_FREE},
         }},
        {.id = 3U, .reference = "sample_photo(1)/132.png",
         .emitter = {.enabled = 1, .point = {972.875f, 517.375f}, .direction = {-0.999621787f, 0.02750059938f}},
         .object_count = 4, .objects = {
            {.anchor = {.type = RAY_OBJECT_TARGET,
                .center = {312.0f, 283.0f}, .axis = {1.0f, 0.0f},
                .direction_valid = 0},
             .motion = GAME_FREE},
            {.anchor = {.type = RAY_OBJECT_PORTAL_A,
                .center = {847.5f, 507.5f}, .axis = {0.0f, -1.0f},
                .direction_valid = 0},
             .motion = GAME_FREE},
            {.anchor = {.type = RAY_OBJECT_PORTAL_B,
                .center = {431.75f, 119.625f}, .axis = {0.01750082002f, -0.9998468489f},
                .direction_valid = 0},
             .motion = GAME_FREE},
            {.anchor = {.type = RAY_OBJECT_MIRROR,
                .center = {293.125f, 105.125f}, .axis = {0.6819761449f, -0.731374417f},
                .direction_valid = 0},
             .motion = GAME_FREE},
         }},
    }
};

const GameMenuLayout game_default_menu_layout = {
    .version = GAME_MENU_VERSION,
    .width = 1280, .height = 800, .level_count = 3,
    .levels = {
        {.level_id = 1U, .rect = {80, 64, 320, 100}},
        {.level_id = 2U, .rect = {480, 64, 320, 100}},
        {.level_id = 3U, .rect = {880, 64, 320, 100}},
    },
    .start = {480, 650, 320, 100}
};
const GamePumpConfig game_default_pump_config = {
    .tick_ms = 10ULL
};
const GameRenderConfig game_default_render_config = {
    .version = GAME_RENDER_VERSION, .scene = {80, 192, 880, 420}
};
